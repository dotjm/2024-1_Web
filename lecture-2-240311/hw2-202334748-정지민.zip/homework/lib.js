/* 자바스크립트 파일 ib.js */
function over(obj) {
    obj.src="./media/banana.jpg";
}
function out(obj) {
    obj.src="./media/apple.jpg";
}